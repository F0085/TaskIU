<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles_UsuarioModel;

class Roles_UsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles_usuario=Roles_UsuarioModel::all();
         return view('ingreso_roles')->with(['roles_usuario'=>$roles_usuario]);    
     }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rolBuscar=Roles_UsuarioModel::where('descripcion',$request->Nombre_Rol)->first();
        if(is_null($rolBuscar)){
            $roles= new Roles_UsuarioModel();
            $roles->descripcion=$request->Nombre_Rol;
            $roles->nivel=$request->Nivel_Rol;
            $roles->save();
            return back()->with(['rol_existe'=>'Registro exitoso','success'=>'success']);;            
        }else{
            return back()->with(['rol_existe'=>'Rol ya se encuentra ingresado']);   
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
