<?php
  session_start(); 
    
?>

<?php $__env->startSection('contenido'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Organization Chart Plugin</title>
    <link rel="icon" href="img/logo.png">
    <link rel="stylesheet" href="css/jquery.orgchart.css">
    <script
    src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <!--   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> -->

    <style type="text/css">
      #ul-data {
        position: relative;
        top: -60px;
        display: inline-block;
        margin-left: 10%;
        width: 30%;
        margin-right: 6%;
      }
      #chart-container { display: inline-block; width: 50%; }
      #ul-data li { font-size: 32px; }
    </style>
  </head>
  <body  >
    <form class="table-responsive" style="overflow:scroll; height:100%; width:100%;">
      <ul id="ul-data" style="display: none">
        <li>CLINICA CARDIOCENTRO MANTA
          <ul>
            <?php $__currentLoopData = $DistintAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($v['Area']); ?>  
              <ul >
                <?php $__currentLoopData = $AreasRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <?php if($valor['Area']==$v['Area']): ?>
                <li><center>



                  <?php echo e('<'.'a style="cursor: pointer" onclick="UserRol('.$valor['Id_Area'].','.$valor['Id_Roles'].');" data-toggle="modal" data-target="#inforOrganigrama" >'.$valor['Rol'].'</a>'); ?></center>
 <!--                  <ul>
                    <li>hola</li>
                    <li>hol3</li>
                  </ul> -->
                </li><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <!--  <li>Hei Hei
                  <ul>
                    <li>Pang Pang</li>
                    <li>Xiang Xiang</li>
                  </ul>
                </li> -->
              </ul>
            </li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </li>
      </ul>
      <div id="chart-container"></div>
    </form>
    <!--   <script type="text/javascript" src="js/jquery.min.js"></script> -->
     <?php echo $__env->make('Organigrama.modalInforOrg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="text/javascript">
      $(function() {

        $('#chart-container').orgchart({
          'data' : $('#ul-data')
        });

      });
    </script>
          <script src="<?php echo e(asset('js/Organigrama.js')); ?>"></script>
  </body>
</html>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TaskManta\resources\views/Organigrama/Organigrama.blade.php ENDPATH**/ ?>