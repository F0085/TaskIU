<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Roles_UsuarioModel extends Model
{
    protected $table='roles_usuario';
    protected $primaryKey="idroles_usuario";
    public $timestamps = false;

}
